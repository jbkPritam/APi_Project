package com.Kiranacademy.productcategoryrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductcategoryRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
