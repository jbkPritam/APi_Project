package com.Kiranacademy.productcategoryrestapi;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("productapi")

public class ProductController {
	@Autowired
	SessionFactory factory;
	
	@PostMapping("product/{cid}")
	public Product addProduct(@RequestBody Product product,@PathVariable int cid)
	{
		System.out.println("Category id is " + cid);
		
		Session session=factory.openSession();
		
		Category category=session.load(Category.class,cid);
				
		
		/* get list of product and add product into it  */
		
		List<Product> productlist=category.getProducts();
			
		
		Transaction transaction=session.beginTransaction();
		
			productlist.add(product);
						
		transaction.commit();
		
		
		System.out.println("product added into database");
		
		return product;
		
	
	}	

}
